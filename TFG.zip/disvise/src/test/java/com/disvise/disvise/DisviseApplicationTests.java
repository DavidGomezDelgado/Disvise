package com.disvise.disvise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisviseApplicationTests {

	@Test
	void contextLoads() {
	}

}
